import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.SerializationException;
import kafka.avro.SebAccount;

public class Payment implements Runnable {

	private String accountNr;
	private String source;
	//private double amountSpent;

	// source should be either SWISH or CREDIT
	Payment(String accountNr, String source) {
		this.accountNr = accountNr;
		this.source = source;
	}

	@Override
	public void run() {
		Properties propsProducer = new Properties();
		propsProducer.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		propsProducer.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
				org.apache.kafka.common.serialization.StringSerializer.class);
		propsProducer.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, AvroSerializer.class);

		KafkaProducer<Object, Object> producer = new KafkaProducer<Object, Object>(propsProducer);

		String key = "money-spent";

		boolean running = true;
		while (running) {
			// assume that amountSpent is some number between 10 to 1000; 
			double amountSpent = ThreadLocalRandom.current().nextDouble(10, 1000);
			SebAccount sebAccount = SebAccount.newBuilder()
					.setAccount(accountNr)
					.setAmount(amountSpent)
					.setSource(source)
					.build();
			final String topic = "seb-account-topic";

			ProducerRecord<Object, Object> recordProducer = new ProducerRecord<Object, Object>(topic, sebAccount);
			if (getBalance(accountNr) < amountSpent) {
				System.out.printf("From producer: AmountSpent is %, .2f \n", amountSpent);
				System.out.printf("Account: "+ accountNr + ", Balance = %, .2f, not enough, stop spending! \n", getBalance(accountNr));
				System.out.println("======================================");
				break;
			}

            try {
                producer.send(recordProducer);
            } catch (SerializationException e) {
                // may need to do something with it
            }
			
			// Sleep 5 seconds
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				running = false;
				e.printStackTrace();
			}
			
		}
		
		producer.flush();
		producer.close();

	}

	double getBalance(String accountNr) {
		return BalanceController.getBalance(accountNr);
	}

}
