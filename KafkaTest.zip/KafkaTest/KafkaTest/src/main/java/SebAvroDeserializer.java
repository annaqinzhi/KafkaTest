import kafka.avro.SebAccount;

public class SebAvroDeserializer extends AvroDeserializer<SebAccount> {
        public SebAvroDeserializer () {
        	super(SebAccount.class);
        }
}
