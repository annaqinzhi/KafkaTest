echo "=============================="
echo "     START the zookeeper!     "
echo "=============================="
/usr/src/myapp/kafka_2.13-2.6.0/bin/zookeeper-server-start.sh /usr/src/myapp/kafka_2.13-2.6.0/config/zookeeper.properties > log1  &

sleep 3s

echo "=============================="
echo "     START the kafka!         "
echo "=============================="
/usr/src/myapp/kafka_2.13-2.6.0/bin/kafka-server-start.sh /usr/src/myapp/kafka_2.13-2.6.0/config/server.properties > log2 &

sleep 3s

echo "=============================="
echo "     START the java jar!      "
echo "=============================="
java -jar /usr/src/myapp/KafkaTest.jar
